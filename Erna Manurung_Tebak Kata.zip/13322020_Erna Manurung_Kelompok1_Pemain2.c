#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/msg.h>
#include <sys/ipc.h>

#define MAX_NAME_LENGTH 50
#define MAX_KISI_LENGTH 1000

struct Message
{
    long mType;
    char mData[MAX_KISI_LENGTH];
};

int main()
{
    char namaPemain2[MAX_NAME_LENGTH];
    char kisi[MAX_KISI_LENGTH];

    printf("Selamat Datang di Permainan Tebak Kata - Pemain 2\n");
    printf("Masukkan Nama Pemain 2: ");
    scanf("%s", namaPemain2);

    // Membuat atau mendapatkan message queue
    key_t key = ftok("kata_dan_kisi.txt", 'A');
    if (key == -1)
    {
        perror("Gagal membuat key");
        return 1;
    }

    int msgid = msgget(key, 0666 | IPC_CREAT);
    if (msgid == -1)
    {
        perror("Gagal membuat atau mendapatkan message queue");
        return 1;
    }

    // Membaca pesan dari message queue
    struct Message msg;
    if (msgrcv(msgid, &msg, sizeof(msg.mData), 1, 0) == -1)
    {
        perror("Gagal membaca pesan");
        return 1;
    }

    // Parsing pesan menjadi kata dan kisi-kisi
    char kata[MAX_NAME_LENGTH];
    sscanf(msg.mData, "%s %[^\n]s", kata, kisi); // Mengambil kata dan kisi-kisi dari pesan

    // Menampilkan kisi-kisi yang diberikan oleh Pemain 1
    printf("\nSelamat datang di permainan tebak kata, %s!\n", namaPemain2);
    printf("Kisi-kisi yang diberikan:\n%s\n", kisi);

    int kesempatan = 6;

    while (kesempatan > 0)
    {
        printf("%s, tebak kata (%d kesempatan): ", namaPemain2, kesempatan);
        char tebakan[MAX_NAME_LENGTH];
        scanf("%s", tebakan);

        if (strcmp(kata, tebakan) == 0)
        {
            printf("Selamat, %s! Anda benar. Anda memenangkan ronde 1!\n", namaPemain2);
            break;
        }
        else
        {
            kesempatan--;
            printf("Maaf, %s, tebakan Anda salah. Sisa kesempatan: %d\n", namaPemain2, kesempatan);
        }
    }

    printf("=== PERMAINAN BERAKHIR ===\n");

    return 0;
}