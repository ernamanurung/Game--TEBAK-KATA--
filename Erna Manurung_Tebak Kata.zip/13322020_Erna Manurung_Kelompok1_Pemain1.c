#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/msg.h>
#include <sys/ipc.h>

#define MAX_NAME_LENGTH 50
#define MAX_KISI_LENGTH 1000

struct Message
{
    long mType;
    char mData[MAX_KISI_LENGTH];
};

int main()
{
    char namaPemain1[MAX_NAME_LENGTH];
    char kata[MAX_NAME_LENGTH];
    char kisi[MAX_KISI_LENGTH];

    printf("Selamat Datang di Permainan Tebak Kata - Pemain 1\n");
    printf("Masukkan Nama Pemain 1: ");
    scanf("%49s", namaPemain1);

    printf("\nSelamat datang di permainan tebak kata, %s!\n", namaPemain1);
    printf("%s, berikan kata yang akan ditebak oleh Pemain 2: ", namaPemain1);
    scanf("%49s", kata);

    printf("%s, berikan kisi-kisi atau petunjuk (lebih dari tiga kata):\n", namaPemain1);

    for (int i = 1; i <= 3; i++)
    {
        printf("Yang ke-%d: ", i);
        char pertanyaan[100];
        scanf(" %99[^\n]s", pertanyaan); // Menggunakan batasan untuk mencegah overflow
        strcat(kisi, pertanyaan);
        strcat(kisi, "\n");
    }

    printf("\n=== RONDE 1 ===\n");
    printf("Selamat datang di permainan tebak kata, %s!\n", namaPemain1);
    printf("Kata yang diberikan: %s\n", kata);
    printf("Kisi-kisi yang diberikan:\n%s", kisi);

    // Membuat atau mendapatkan message queue
    key_t key = ftok("kata_dan_kisi.txt", 'A');
    if (key == -1)
    {
        perror("Gagal membuat key");
        return 1;
    }

    int msgid = msgget(key, 0666 | IPC_CREAT);
    if (msgid == -1)
    {
        perror("Gagal membuat atau mendapatkan message queue");
        return 1;
    }

    // Mengirim kata dan kisi-kisi melalui message queue
    struct Message msg;
    msg.mType = 1; // Jenis pesan
    snprintf(msg.mData, sizeof(msg.mData), "%s\n%s", kata, kisi);

    if (msgsnd(msgid, &msg, sizeof(msg.mData), 0) == -1)
    {
        perror("Gagal mengirim pesan");
        return 1;
    }

    return 0;
}